# Reader Export Button

Allows a Reader user to export their subscriptions in OPML format.

## Props

| Prop | Type | Required | Description |
|-----|:----:|:--------:|-------------|
| `saveAs`| String | No | The filename to use when saving the export - defaults to wpcom-subscriptions.opml |
