App Promo
=========

This component is used to suggest the desktop app to users. 

#### How to use:

```js
import AppPromo from 'components/app-promo'

render: function() {
	return (
		<AppPromo />
	);
}
```
