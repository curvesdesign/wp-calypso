# Reader Site Notifications Settings

Provides a Settings link with a popover containing notification settings for the specified site.

## Props

| Prop | Type | Required | Description |
|-----|:----:|:--------:|-------------|
| `siteId`| Number | Yes | The site ID to manage notifications for |
