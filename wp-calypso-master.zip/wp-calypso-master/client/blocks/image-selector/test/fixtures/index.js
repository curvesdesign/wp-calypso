/** @format */
export const DUMMY_SITE_ID = 1;

export const DUMMY_MEDIA = {
	100: {
		ID: 100,
		title: 'Sunset',
	},
};
