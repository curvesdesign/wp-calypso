# Followers Count

`FollowersCount` displays a button with the `subscriber_count` of the currently selected `site`, linked to the new-ish `people/followers` page.

## Example

```js
import FollowersCount from 'blocks/followers-count';

render() {
	return (
		<FollowersCount />
	);
}
```