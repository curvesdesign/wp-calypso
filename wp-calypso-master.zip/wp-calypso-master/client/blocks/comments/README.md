# Comments

A component that displays threaded comments for a post.

## Props

- `post`: A post to show comments for