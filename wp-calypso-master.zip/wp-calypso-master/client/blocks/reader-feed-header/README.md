# Reader Feed Header

The header for the feed/site stream. This can combine information from a site and a feed object to come up with the final display.

## Props

- `site`: The site to use for the header
- `feed`: The feed to use for the header
- `showBack`: Show the back button?