/** @format */
export const ALLOWED_FILE_EXTENSIONS = [ 'jpg', 'jpeg', 'png', 'gif', 'bmp' ];
