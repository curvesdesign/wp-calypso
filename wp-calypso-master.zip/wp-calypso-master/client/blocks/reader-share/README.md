# Reader Share

A component that wraps up the Share button and Popover Menu that results from using it.

## Props

- `tagName`: string or ReactComponent, the component to render as the root of this component.
- `position`: string, the PopoverMenu position to use
- `post`: object, the post to share
