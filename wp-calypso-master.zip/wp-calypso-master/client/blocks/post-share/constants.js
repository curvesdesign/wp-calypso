/** @format */

export const SCHEDULED = 'scheduled';
export const PUBLISHED = 'published';
